
  describe('Apollo demo', function() {
      browser.get('https://vab.be');
      browser.sleep(5000);;
    });

    it('Klik op mijn VAB', function() {;
      console.log("Klik op mijn VAB")
      element(by.xpath('/html/body/header/div/section/div[2]/div[4]/nav[1]/ul/li[2]/a')).click();
      browser.sleep(5000);
    });

 
    it('Go to Contacts page', function() {
      console.log("Go to Contacts page")
      element(by.xpath('//*[@id="sitemap-entity-NewSubArea_8211c596"]')).click();
      browser.sleep(5000);
    });

    it('Click on new button', function() {
      console.log("Clicking on New button")
     element(by.xpath('//*[@id="contact|NoRelationship|HomePageGrid|Mscrm.NewRecordFromGrid11-button"]')).click();
     browser.sleep(5000);  
    });

