﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
namespace Selenium_demo
{
   public class Accounts
    {
        public void AddNewAccount(IWebDriver driver)
        {

        }
    }
}
