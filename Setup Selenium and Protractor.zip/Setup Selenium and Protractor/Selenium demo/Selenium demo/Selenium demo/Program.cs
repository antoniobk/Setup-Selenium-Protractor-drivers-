﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Edge;

namespace FollowIT___Automation
{
    
    class Program
    {
        static void Main(string[] args)
        {
            
            IWebDriver driver = new EdgeDriver("C:");

            driver.Navigate().GoToUrl("https://www.vab.be");
            driver.Manage().Window.Maximize();



        }

    }
   }
